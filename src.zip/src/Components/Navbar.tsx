import React from "react";

export const Navbar: React.FC = () => (
   <nav>
       <div className="nav-wrapper">
           <a href="#" className="brand-logo">React + Typesript</a>
           <ul className="right hide-on-med-and-down">
               <li><a href="/">События</a></li>
           </ul>
       </div></nav>
)