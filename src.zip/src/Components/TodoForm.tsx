import React, {useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import {RootState} from "../redux/store";
import {addEvent, clearEvents} from "../redux/testSlice";

export const  TodoForm: React.FC = () => {
    const events = useSelector((state:RootState) => state.test.events);
    const dispatch = useDispatch();
    const [nameEvent, setNameEvent] = useState('');
    const [dateEvent, setDateEvent] = useState('');

    const clearState =() => {
        dispatch(clearEvents());
    }

    const addEventInState = () => {
        dispatch(addEvent({data: 0, events: nameEvent}));
    }

    return (
        <div className="input-field mt2">
           <input type="text"
                  placeholder="Введите название события"
                  value={nameEvent}
                  onChange={(e) => setNameEvent(e.target.value) }/>
            <input type="date"
                   placeholder="Введите Дату"
                   value={dateEvent}
                   onChange={(e) => setDateEvent(e.target.value) }/>
           <label htmlFor="title" className="active">
              Введите название события
           </label>
            <ul>
                {events.map(item => {
                    return (
                        <li>
                            Дата:{item.data}, Событие:{item.events}
                        </li>
                    )
                })}
            </ul>
            <button onClick={clearState}>Очистить</button>
            <button onClick={addEventInState}>add</button>
        </div>
    )

}
