import {createSlice, PayloadAction} from '@reduxjs/toolkit'

export const testSlice = createSlice({
    name: 'test',
    initialState: {
        events: [
            {
                data: 123123,
                events: 'awdawd',
            }
        ],
    },

    reducers: {
        clearEvents: (state) => {
           state.events = [];
        },
        addEvent: (state, action: PayloadAction<{data: number, events: string}>) => {
            state.events.push(action.payload);
        }
    },
})

// Action creators are generated for each case reducer function
export const { clearEvents, addEvent } = testSlice.actions


export default testSlice.reducer
